Android Settings Shortcut
-------------------------
This XBMC add-on will allow a user to launch the native Android Settings application from within XBMC.

Requires XBMC 12+ with the following patch:
https://github.com/mcrosson/xbmc/commit/153a584a41d21189a3935f3430301ad84f41ccec
