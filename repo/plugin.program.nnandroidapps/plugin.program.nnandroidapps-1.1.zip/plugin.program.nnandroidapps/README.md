XBMC Android Apps
=============
XBMC add-on that makes it easier to create a shortcut to the list of android apps
